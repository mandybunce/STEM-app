<html>
<?php
  header("location:WebPage/stemPageStart.php");
?>
</html>
